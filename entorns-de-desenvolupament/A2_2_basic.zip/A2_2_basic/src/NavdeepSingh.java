public class NavdeepSingh {
    public static void main(String[] args) throws Exception {
        System.out.println("Hola classe, s\\u00f3c Navdeep Singh!");
    }
}
